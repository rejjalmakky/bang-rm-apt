# -*- tcl -*-
# Tcl package index file, version ???
#
package ifneeded sqlite3 3.50.4 \
    [list load [file join $dir libsqlite3.50.4.so] Sqlite3]

